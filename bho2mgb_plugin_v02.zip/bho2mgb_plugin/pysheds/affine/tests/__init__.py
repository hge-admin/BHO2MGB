"""Affine tests package"""
